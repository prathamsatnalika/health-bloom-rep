const List categories = [
  {"name": "Prescription", "icon": "https://assets9.lottiefiles.com/packages/lf20_vPnn3K.json"},
  {"name": "Bills", "icon": "https://assets9.lottiefiles.com/temp/lf20_P64fWH.json"},
  {"name": "Reports", "icon": "https://raw.githubusercontent.com/prathamsatnalika/lottie/main/lf30_editor_6efhqj5k.json"},
];
